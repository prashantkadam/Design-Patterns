package genericDeser.util;
/**
 * Class Statistics
 * 
 * @author PRASHANT
 *
 */
public class Statistics {
	/**
	 * Private Data Members
	 */
	private int totalFirst;
	private int totalSecond;
	private int uniqueFirst;
	private int uniqueSecond;

	/**
	 * getTotalFirst
	 * 
	 */
	public int getTotalFirst() {
		return totalFirst;
	}

	/**
	 * getTotalFirst
	 * 
	 */
	public void setTotalFirst(int totalFirst) {
		this.totalFirst = totalFirst;
	}

	/**
	 * getTotalFirst
	 * 
	 */
	public int getTotalSecond() {
		return totalSecond;
	}

	/**
	 * setTotalSecond
	 * 
	 */
	public void setTotalSecond(int totalSecond) {
		this.totalSecond = totalSecond;
	}

	/**
	 * getUniqueFirst
	 * 
	 */
	public int getUniqueFirst() {
		return uniqueFirst;
	}

	/**
	 * setUniqueFirst
	 * 
	 */
	public void setUniqueFirst(int uniqueFirst) {
		this.uniqueFirst = uniqueFirst;
	}

	/**
	 * getUniqueSecond
	 * 
	 */
	public int getUniqueSecond() {
		return uniqueSecond;
	}

	/**
	 * setUniqueSecond
	 * 
	 */
	public void setUniqueSecond(int uniqueSecond) {
		this.uniqueSecond = uniqueSecond;
	}
}

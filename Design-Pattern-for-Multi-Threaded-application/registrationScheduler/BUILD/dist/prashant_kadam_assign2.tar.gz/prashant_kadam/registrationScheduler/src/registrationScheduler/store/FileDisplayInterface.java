package registrationScheduler.store;

/**
 * FileDisplayInterface Interface
 * @author PRASHANT
 *
 */
public interface FileDisplayInterface {
	void writeSchedulesToFile(String outputFileName);
}

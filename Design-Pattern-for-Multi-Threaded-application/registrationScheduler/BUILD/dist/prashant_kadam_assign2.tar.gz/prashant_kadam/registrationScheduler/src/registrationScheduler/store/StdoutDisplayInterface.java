
package registrationScheduler.store;

/**
 * StdoutDisplayInterface Interface
 * @author PRASHANT
 *
 */
public interface StdoutDisplayInterface {
    public void writeSchedulesToScreen();
}

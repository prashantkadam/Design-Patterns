
CS-542 Design Patterns
Fall 2016
PROJECT 2 README FILE

Due Date: 11.59 PM EST on Friday, Sept 30, 2016.
Submission Date: Friday, Sept 30, 2016
Grace Period Used This Project:  N/A
Grace Period Remaining:  N/A
Author: Prashant Kadam
e-mail: pkadam1@binghamton.edu


PURPOSE:

[
  Application of design principles for a simple multi-threaded application.
]

PERCENT COMPLETE:

[
  100%
]

PARTS THAT ARE NOT COMPLETE:

[
   N/A
]

BUGS:

[
  N/A
]

FILES:

[
  Included with this project are 5 files:

  -----------------------------------------------
  Package Name                     file Name
  -----------------------------------------------
  Driver                            
                                    Driver.java

  registration                      
                                    Allocator.java
                                    Course.java
                                    Student.java

  store                             
                                  FileDisplayInterface.java
                                  Results.java
                                  StdoutDisplayInterface.java
  threadMgmt
                                  CreateWorkers.java
                                  WorkerThread.java
  util                      
                                  FileProcessor.java
                                  Logger.java
                                  ObjectPool.java

  build.xml

  README.txt - ReadMe file

  -----------------------------------------------
]

SAMPLE OUTPUT:
geneates Output file with content as 
[

Student_1 A B C E F 17.0
Student_2 A B C E F 17.0
Student_3 A B C E F 17.0
Student_4 A B C E F 17.0
Student_5 A B C E F 17.0
Student_6 A B C E F 17.0
Student_7 A B C E F 17.0
Student_8 A B C E F 17.0
Student_9 A B C E F 17.0
Student_10 A B C E F 17.0
Student_11 A B C E F 17.0
Student_12 A B C E F 17.0
Student_13 A B C E F 17.0
Student_14 A B C E F 17.0
Student_15 A B C E F 17.0
Student_16 A B C E F 17.0
Student_17 A B C E F 17.0
Student_18 A B C E F 17.0
Student_19 A B C E F 17.0
Student_20 A B C E F 17.0
Student_21 A B D E F 18.0
Student_22 A B D E F 18.0
Student_23 A B D E F 18.0
Student_24 A B D E F 18.0
Student_25 A B D E F 18.0
Student_26 A B D E F 18.0
Student_27 A B D E F 18.0
Student_28 A B D E F 18.0
Student_29 A B D E F 18.0
Student_30 A B D E F 18.0
Student_31 A B D E F 18.0
Student_32 A B D E F 18.0
Student_33 A B D E F 18.0
Student_34 A B D E F 18.0
Student_35 A B D E F 18.0
Student_36 A B D E F 18.0
Student_37 A B D E F 18.0
Student_38 A B D E F 18.0
Student_39 A B D E F 18.0
Student_40 A B D E F 18.0
Student_41 A C D E G 20.0
Student_42 A C D E G 20.0
Student_43 A C D E G 20.0
Student_44 A C D E G 20.0
Student_45 A C D E G 20.0
Student_46 A C D E G 20.0
Student_47 A C D E G 20.0
Student_48 A C D E G 20.0
Student_49 A C D E G 20.0
Student_50 A C D E G 20.0
Student_51 A C D E G 20.0
Student_52 A C D E G 20.0
Student_53 A C D E G 20.0
Student_54 A C D E G 20.0
Student_55 A C D E G 20.0
Student_56 A C D E G 20.0
Student_57 A C D E G 20.0
Student_58 A C D E G 20.0
Student_59 A C D E G 20.0
Student_60 A C D E G 20.0
Student_61 B C D F G 22.0
Student_62 B C D F G 22.0
Student_63 B C D F G 22.0
Student_64 B C D F G 22.0
Student_65 B C D F G 22.0
Student_66 B C D F G 22.0
Student_67 B C D F G 22.0
Student_68 B C D F G 22.0
Student_69 B C D F G 22.0
Student_70 B C D F G 22.0
Student_71 B C D F G 22.0
Student_72 B C D F G 22.0
Student_73 B C D F G 22.0
Student_74 B C D F G 22.0
Student_75 B C D F G 22.0
Student_76 B C D F G 22.0
Student_77 B C D F G 22.0
Student_78 B C D F G 22.0
Student_79 B C D F G 22.0
Student_80 B C D F G 22.0

 Average preference value: 19.25


]

Assuming you are in the directory containing this README:

## To clean:
ant -buildfile src/build.xml clean

## To compile: 
ant -buildfile src/build.xml all

## To run by specifying arguments from command line [similarly for the 2nd argument and so on ...]
## We will use this to run your code
ant -buildfile src/build.xml run -Darg0=firstarg 

## To run by specifying args in build.xml (just for debugging, not for submission)
ant -buildfile src/build.xml run

## To create tarball for submission
ant -buildfile src/build.xml tarzip

## if using sh script use 
./run.sh driver <input.txt> <output.txt> <No of threads> <debug level>


##To UNTAR :

tar -xvf prashant_kadam_assign2.tar.gz


Data Structure:

[
using hashmap - Time Complexity are O(1) for search and insert operation so all insert and search will be faster 
      
utilising following two hashmap.

Map<Integer, Student> studentDictionary 
Map<Character, Course> courseDictionary

]

EXTRA CREDIT:

[
  N/A
]


BIBLIOGRAPHY:

This serves as evidence that we are in no way intending Academic Dishonesty.

[
refered java collection methods and syntax on how to use form tutorialPoint.com 
]

ACKNOWLEDGEMENT:

[
 N/A

]
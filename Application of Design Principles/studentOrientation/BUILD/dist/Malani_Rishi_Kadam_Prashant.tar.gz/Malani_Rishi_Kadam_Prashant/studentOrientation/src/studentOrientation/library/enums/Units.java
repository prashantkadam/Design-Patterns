package studentOrientation.library.enums;

public enum Units {
	CALORIES, TONNESOFCO2, DOLLARS, MINUTES;
}

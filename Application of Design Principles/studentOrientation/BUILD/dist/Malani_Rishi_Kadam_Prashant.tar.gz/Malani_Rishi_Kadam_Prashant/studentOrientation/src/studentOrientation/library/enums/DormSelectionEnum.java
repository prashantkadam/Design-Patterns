package studentOrientation.library.enums;

/**
 * Enum for DormSelection Activity
 * @author rishimalani <rmalani1@binghamton.edu>
 *
 */
public enum DormSelectionEnum {
	AdministratorOffice, OnlineGaming
}

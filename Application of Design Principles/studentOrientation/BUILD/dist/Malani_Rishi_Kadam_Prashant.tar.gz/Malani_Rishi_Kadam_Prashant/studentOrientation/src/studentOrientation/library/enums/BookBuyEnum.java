package studentOrientation.library.enums;

/**
 * Enum for BookBuy Activity
 * @author rishimalani <rmalani1@binghamton.edu>
 *
 */
public enum BookBuyEnum {
	UniverstiyStore, MondoStore
}

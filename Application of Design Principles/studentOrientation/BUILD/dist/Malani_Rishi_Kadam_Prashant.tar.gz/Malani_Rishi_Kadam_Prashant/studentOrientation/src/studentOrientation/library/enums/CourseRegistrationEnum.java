package studentOrientation.library.enums;

/**
 * Enum for CourseRegistration Activity
 * @author rishimalani <rmalani1@binghamton.edu>
 *
 */
public enum CourseRegistrationEnum {
	 RegistrarOffice, ComputerSystem
}

package studentOrientation.library.enums;

/**
 * Enum for CampusTour Activity
 * @author rishimalani <rmalani1@binghamton.edu>
 *
 */
public enum CampusTourEnum {
	BusRide, OnFoot
}
